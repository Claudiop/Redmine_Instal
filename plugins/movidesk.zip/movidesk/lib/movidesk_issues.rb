module MovideskIssues
	class WebhookListener < Redmine::Hook::Listener    
	  def controller_issues_edit_after_save(context = {})    
		  issue = context[:issue]    
		  MovideskNotifier.update(issue.status.id, issue.notes, issue.id, context[:journal].user.id, issue.private_notes, issue.updated_on)	  
	  end
	  
	  def controller_issues_bulk_edit_before_save(context = {})    
		  issue = context[:issue]    
		  MovideskNotifier.update(issue.status.id, issue.notes, issue.id, nil, issue.private_notes, issue.updated_on)	  
	  end 
	end  
end  
