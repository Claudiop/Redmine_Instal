require 'net/http'
require 'net/https'
require 'uri'

class MovideskNotifier
  def self.my_logger
    @@my_logger ||= Logger.new("#{Rails.root}/log/movidesk.log")
  end

  def self.update(statusId, notes, id, authorId, isPrivate, updatedOn)   

	params = {      
		:notes => notes,
		:statusId => statusId,
		:issueId => id,
		:authorId => authorId,
		:isPrivate => isPrivate,
	    :updatedOn => updatedOn
	}.to_json

	put_request(params)
  end


	def self.put_request(params) 
		uri = URI.parse('https://api.movidesk.com')				
		http = Net::HTTP.new(uri.host, uri.port)
		
		http.use_ssl = true
		http.verify_mode = OpenSSL::SSL::VERIFY_NONE
		
		api_token    = Setting.plugin_movidesk['api_token']
		request = Net::HTTP::Post.new("/public/v1/redmine_issues?token=#{api_token}")
		request.add_field('Content-Type', 'application/json')
		request.body = params
		http.request(request)
		
		self.my_logger.info("Token: #{api_token}. Params: #{params}.")
	end
end
