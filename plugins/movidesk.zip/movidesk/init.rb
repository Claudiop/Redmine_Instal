PT_VERSION = "1.1.2"

require 'redmine'

require_dependency 'movidesk_notifier'
require_dependency 'movidesk_issues'

Redmine::Plugin.register :movidesk do
  name 'Redmine -> Movidesk - Integração de Tickets'
  author 'Movidesk'
  description 'Mantém os tickets associados ao Redmine atualizados no Movidesk'
  version PT_VERSION
  author_url 'http://www.movidesk.com/'

  settings(:partial => 'settings/movidesk_settings',
           :default => {
            'api_token'  => ''            
          })
end
